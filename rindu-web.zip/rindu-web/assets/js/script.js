$(document).ready(function() {
  const BASE_URL = "https://nodejs-project-rindu-backend.onrender.com/api/messages";

  function getAllMessages() {
    $.ajax({
      url: BASE_URL,
      method: 'GET',
      success: function(response) {
        // Clear existing table rows
        $('#list tbody').empty();

        // Iterate over each message and append to table
        response.data.forEach(function(message, index) {
          $('#list tbody').append(`
            <tr>
              <td>${index + 1}</td>
              <td>${message.User.full_name}</td>
              <td>${message.text}</td>
            </tr>
          `);
        });
      },
      error: function(xhr, status, error) {
        console.error("Error fetching messages:", error);
      }
    });
  }

  // Call getAllMessages function when the document is ready
  getAllMessages();
});